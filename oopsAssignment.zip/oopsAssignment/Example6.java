/*Create interface Polynomial with following methods readValues(), calculateResult(),
printResult(). Now you have to implements those methods for (a+b)2 and (a+b)3*/

import java.util.Scanner;

interface Polynomial {
	
	 void readValues(int a,int b);
	 void calculateResult(int a, int b);
	 void printResult(int c, int d);
}

class Calculator implements Polynomial {

	public void readValues(int a, int b) {
	calculateResult(a, b);
	}

	public void calculateResult(int a, int b) {
	int c = 0;
	int d = 0;
	c= (a*a) + (b*b) + (2*a*b);
	d = (a*a*a) + (b*b*b) + 3 *a*b *(a+b);
	printResult(c, d);
	}

	public void printResult(int c, int d) {
	System.out.println("(a+b)^2 = a2+b2+2ab = " +c);
	System.out.println("(a+b)^3 = a3 + b3 + 3ab(a + b) = "+ d);

	}
}
class Example6 {

	public static void main(String[] args) {
		Calculator result = new Calculator();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a &b:");
		int a=sc.nextInt();
		int b=sc.nextInt();
		result.readValues(a,b);
	}

}