/*Write down a class Person with following fields pid,pname, paddress, all class
variables are private and setter, getter should be use. Now create two classes
employee and customer who extends Person class. Employee will have following
fields :- deptname, location, salary, pfdeduction, post, email, dateof_registration,
date_of_joining . Customer :- custemail, doregistration,
Now you have to create object of Customer and Employee and print all values You have to initialize Person class variable too.
*/

class Person {
	private int pId; 
	private String  pAddress;  
    private String  pName;
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpAddress() {
		return pAddress;
	}
	public void setpAddress(String pAddress) {
		this.pAddress = pAddress;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	
	@Override  
    public String toString()   
    {  
        String str = "Person: pid = " + getpId() + ", pname = " + getpName() + ", paddress = " + getpAddress();  
        return str;  
    } 

}

class Customer extends Person
{

	private String custemail;
	private String doRegistration;

	 public String getCustemail() {
		return custemail;
	}

	public void setCustemail(String custemail) {
		this.custemail = custemail;
	}

	public String getDoRegistration() {
		return doRegistration;
	}

	public void setDoRegistration(String doRegistration) {
		this.doRegistration = doRegistration;
	}

	public void customerdisplay() {
		 System.out.println(" Customer custemail:-" +getCustemail()+ "\n doregistration:-" +getDoRegistration());
	 }

    
}
class Employee extends Person
{
  
	
	 private String deptName;
	 private String location;
	 private double salary;
	 private double pfDeduction;
	 private String post;
	 private String email;
	 private String dateOfRegistration;
	 private String dateOfJoining;
	 
	 public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getPfDeduction() {
		return pfDeduction;
	}

	public void setPfDeduction(double pfDeduction) {
		this.pfDeduction = pfDeduction;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDateOfRegistration() {
		return dateOfRegistration;
	}

	public void setDateOfRegistration(String dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public void display() {
		 System.out.println("deptName:-"+getDeptName() +"\n \n location:-" +getLocation() + "\n salary:-" +getSalary()+ "\n pfDeduction:-" +getPfDeduction()
				+ " \n post :-"+getPost() + "\n email:- " +getEmail() + "\n dateof_registration:- " +getDateOfRegistration() +"\n dateOfJoining:-" +getDateOfJoining());
	 }
}
class Example1
{
	 public static void main(String s[])
	 {  
	        Employee emp = new Employee(); 
	        Customer cust = new Customer();  
	        emp.setpId(107);  
	        emp.setpName("XXX");  
	        emp.setpAddress("XYZ Corporation"); 
	        emp.setDeptName("BU4-BU5");
	        emp.setLocation("banglore");
	        emp.setSalary(25000);
	        emp.setPfDeduction(10000);
	        emp.setPost("Developer");
	        emp.setEmail("yash@gmail.com");
	        emp.setDateOfRegistration("21-09-2022");
	        emp.setDateOfJoining("25-10-2022");
	        cust.setCustemail("supritha@yash.com");
	        cust.setDoRegistration("23-11-2022");

	        emp.display();
	        cust.customerdisplay();   
	        System.out.println(emp);  
	    }
	
}