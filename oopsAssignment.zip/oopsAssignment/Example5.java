/*Create abstract class StringOperation in which you have declare following methods,
mergeString, findChar, getCharArray. Now you have to implement all these methods
in sub classes*/

abstract class StringOperation
{
  abstract void mergeString(String str1, String str2);
  abstract void findChar(String str1, char c);
  abstract void getCharArray(String str1);

}
abstract class String1 extends StringOperation
{
	void  mergeString(String str1, String str2) {
		String str3 = str1+str2;
		System.out.println("Merging string1 and string2 value is:- "+str3);
	}	
}
abstract class String2 extends String1
{
	void findChar(String str1, char c){
		String str = "";
		str+=c;
		int str4 = str1.indexOf(str);
		System.out.println("Charater of J value is:- "+str4);
}	
}

 class String3 extends String2
{
	public void getCharArray(String S1)
	{
		char result[]= new char[S1.length()];
		for (int i = 0; i < S1.length(); i++) {
			result[i] = S1.charAt(i);
			
        }
		 for (char c : result) {
	            System.out.println(c);
	        }  
	}
	}	
}
class OperationDemo
{
	public static void main(String s[])
	{
		String3 obj = new String3();
	    String str1 = "I am a Java ";
		String str2 = "Developer";
		obj.mergeString(str1, str2);
		obj.findChar(str1, 'J');
		obj.getCharArray(str1);		
	}
	
}
