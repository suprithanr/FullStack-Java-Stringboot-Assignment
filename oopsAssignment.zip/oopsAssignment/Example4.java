/*Create interface Shape with method area and result. Now you have to print area of
sphere, rectangle, and cone with same method*/
interface Shape {
	
	public double area(double r,double pi);
	public void result(double l, double w);
}

class Sphere implements Shape {

	public double area(double r, double pi)
	  {
	    double sphere=4*pi*(r*r);
		return sphere;
	  }

	public void result(double r, double pi) {
		double result=area(r, pi);
		System.out.println("Area of the sphere : "+result);
	}
}
class Rectangle implements Shape {

	public double area(double l, double w)
	  {
	    double rectangle=l*w;
		return rectangle;
	  }

	public void result(double l, double w) {
		double result=area(l, w);
		System.out.println("Area of the rectangle : "+result);
	}
}
class Cone implements Shape {

	public double area(double r, double h)
	  {
			double r2=r*r;
			double h2=h*h;
			double rd = r2+h2;
			double cn = Math.sqrt(rd);
			double cone =3.14*r*(r+cn);
			return cone;
		}

	public void result(double r, double h) {
		double result=area(r, h);
		System.out.println("Area of the Cone : "+result);
	}		
}
class Example4 {

	public static void main(String[] args) {
		Rectangle obj = new Rectangle();
		Cone obj2 = new Cone();
		Sphere obj3 = new Sphere();
		 double pi=3.14,l=10,w=5,h=12;
		 double r=2;
		 obj.result(l,w);
		 obj2.result(r, h);
		 obj3.result(r, pi);
	}

}