/*Write down a class Item and Category. Category :- catid, catname. Item :- itemid,
iname, price, category. Category class object need to be pass in constructor of Item
class to set it. Now you have to create object of Item and print detail of item*/

public class Category {
	
	private int categoryId;
	private String categoryName;
	
	
	public Category(int categoryId, String categoryName) {
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

	@Override
	public String toString() {
		return "Category of categoryId=" + categoryId + ", categoryName=" + categoryName + "]";
	}
	
}

class Item
{
	
	int itemId;
	String iname;
	double price;
	Category category;
	
	public Item(int id, String name, double pricing, Category category) {
		 this.itemId= id;
		 this.iname = name;
	     this.price=pricing;
	     this.category=category;
	    
	    }
	
	public void ItemDetailDisplay() {
		
		System.out.println(" ItemNumber:- "+itemId+"\n ItemName:-"+ iname
	    		+" \n Item Price:-"+ price+ "\n ItemCategoryId:- "+category.toString());
	
	}

}
class Example2
{
	 public static void main(String s[])
	 {
	    Category cat = new Category(10, "sweet");
		Item item = new Item(1, "sugar", 20.0, cat);
		item.ItemDetailDisplay();
	 }
	
}