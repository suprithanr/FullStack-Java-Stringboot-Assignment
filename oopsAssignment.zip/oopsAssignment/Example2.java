/*Write down a class Item and Category. Category :- catid, catname. Item :- itemid,
iname, price, category. Category class object need to be pass in constructor of Item
class to set it. Now you have to create object of Item and print detail of item*/

class Category {
	int catid=20;
	String catName="Sweet";

}

class Item
{
	
	int itemId;
	String iname;
	double price;
	Category category;
	
	public Item(int id, String name, double pricing, Category category) {
		 this.itemId= id;
		 this.iname = name;
	     this.price=pricing;
	     this.category=category;
	    
	    }
	
	public void ItemDetailDisplay() {
		
		System.out.println(" ItemNumber:- "+itemId+"\n ItemName:-"+ iname
	    		+" \n Item Price:-"+ price + "\n ItemCategoryId:- "+category.catid + "\n categoryName:- "+category.catName);
	
	}

}
class Example2
{
	 public static void main(String s[])
	 {
	    Category cat = new Category();
		Item item = new Item(1, "sugar", 20.0, cat);
		item.ItemDetailDisplay();
	 }
	
}