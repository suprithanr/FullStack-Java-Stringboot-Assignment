/*Write down a class to find maximum of N numbers, user can enter integer, float or
double and result should be in that format*/


public class Maximum {

	public static Integer maxNumber(Integer[] n) {

		Integer maxNumber = n[0];
		for (int y = 0; y < n.length; y++) {
			if (maxNumber < n[y]) {
				maxNumber = n[y];
			}
		}
		return maxNumber;

	}

	public static Float maxNumber(Float[] n) {

		Float maxNumber = n[0];
		for (int y = 0; y < n.length; y++) {
			if (maxNumber < n[y]) {
				maxNumber = n[y];
			}
		}
		return maxNumber;

	}

	public static Double maxNumber(Double[] n) {

		Double maxNumber = n[0];
		for (int y = 0; y < n.length; y++) {
			if (maxNumber < n[y]) {
				maxNumber = n[y];
			}
		}
		return maxNumber;

	}

	public static void main(String[] args) {

		Integer[] intArray = {1,4,6,9,10};
		Float[] intArray1 = {1.0f,4.0f,6.0f,9.0f,10.1f};
		Double[] intArray2 = {1.00d,4.00d,6.00d,9.00d,11.02d};
		System.out.println(maxNumber(intArray));
		System.out.println(maxNumber(intArray1));
		System.out.println(maxNumber(intArray2));

	}
}