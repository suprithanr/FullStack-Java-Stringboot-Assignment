/*Write down a class to find maximum of N numbers, user can enter integer, float or
double and result should be in that format*/

import java.util.Scanner;

public class Maximum {
    public static void main(String[] args) throws Exception {
    	Scanner sc = new Scanner(System.in);
    	 System.out.println("Enter number of elements");
        double maximum = 0;
        int inputNumber = sc.nextInt();
        System.out.println("Enter " + inputNumber+ " elements to find maximum value in elements");
        while (inputNumber > 0) {
            double inputMaximum = Double.parseDouble(sc.next());

            if (inputMaximum <= 0 || inputNumber <= 0) {
                break;
            }

            else {
                maximum = Math.max(maximum, inputMaximum);
            }

            inputNumber--;

        }

        if (maximum == 0) {
        }

        else {
            System.out.println(maximum);
}
    
    }
}