/*Write down program to print all numbers who’s are greater than average of all
numbers of array*/
import java.util.Arrays;

public class AvgGreaterNumberMain {

	public static void main(String[] args) {
		int arr[] = {1, 5, 4, 6, 9, 10 };
        int a = arr.length;
        System.out.println("Original Int Array: " +Arrays.toString(arr)+"\n");
		AvgGreaterNumber grtNumb= new AvgGreaterNumber();
        grtNumb.printAvgNumb(arr, a);
	}

}
 class AvgGreaterNumber {
	
	 void printAvgNumb(int arr[], int n)
    {
        double avg = 0;
        for (int i = 0; i < n; i++)
            avg =avg+ arr[i];
            avg = avg / n;
     System.out.println("Average number of array is: " +avg+"\n");
     System.out.print("The numbers greater than the average are: ");
        for (int i = 0; i < n; i++)
            if (arr[i] > avg)
                System.out.print(arr[i] + " ");
        
    }
}


