/*Write down program to find out the occurrence of given string in the sentence. You
need to find out every occurrence of the given string with index and count how many
times string is found.*/

import java.util.LinkedHashMap;

public class StringOccuranceEx {

	public static void main(String[] args) {
		String s = "finding out the occurrence of given string in the sentence";
		String[] stringArray = s.split(" ");
		int count = 0;
		LinkedHashMap<String, Integer> mapobj = new LinkedHashMap<>();
		for (int i = 0; i < stringArray.length; i++) {
			String temp = stringArray[i];
			if(mapobj.containsKey(temp)) {
				mapobj.put(temp, mapobj.get(temp)+1);
			} else {
				mapobj.put(temp,1);
			}
			
		}
		System.out.println(mapobj);
	}

}