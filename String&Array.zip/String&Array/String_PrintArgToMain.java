/*Write down program to read n number of words using parameter passed to main. If
any user entered the numbers in list of words than you have to remove it and then you
have to print the words.*/

import java.util.ArrayList;

public class PrintArgToMain{

	public static void main(String[] args) {
		
		ArrayList<String> s = new ArrayList<String>();
		for(int i=0;i<args.length;i++){
			s.add(args[i]);
			
		}
		s.replaceAll(u ->u.replaceAll("[^a-zA-Z]"," "));
		System.out.println(s);
		
		
		
	}

}
