/*Write down program to remove all digits and special character from the given
sentence*/

public class RemoveSpecialCharDigits {

	public static void main(String args[]) {
		String str = "This#string%contains^special*characters&. and digits 124";
		str = str.replaceAll("[^a-zA-Z]", " ");
		System.out.println(str);
	}
}