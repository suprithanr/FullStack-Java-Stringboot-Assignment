/*Write down program to print all words which are having even length.*/

public class EvenLength {
	
	 public static void main(String[] args)
	 {
	 
	  String s = "Even words in string";
	  System.out.println("Original string is :-"+ s);
	  evenWords(s);
	 }
	 
	public static void evenWords(String s)
	 {
	System.out.println("Words which are having even length in string are:- ");
	  for (String word : s.split(" "))
	   if (word.length() % 2 == 0)
	     System.out.println(word);
	 }
	 

	}
